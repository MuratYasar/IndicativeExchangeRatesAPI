﻿using IndicativeExchangeRates.FilterSort;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Deneme2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonXML_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                List<ExpressionFilter> filters = new List<ExpressionFilter>
                {
                    new ExpressionFilter
                    {
                        PropertyName =IndicativeExchangeRates.FilterSort.Enums.FilterColumNames.CurrencyCode,
                        Value ="USD",
                        Comparison =IndicativeExchangeRates.FilterSort.Enums.Comparison.Equal,
                        LogicalOperator =IndicativeExchangeRates.FilterSort.Enums.LogicalOperation.Or
                    },
                    new ExpressionFilter
                    {
                        PropertyName =IndicativeExchangeRates.FilterSort.Enums.FilterColumNames.CurrencyCode,
                        Value ="EUR",
                        Comparison =IndicativeExchangeRates.FilterSort.Enums.Comparison.Equal,
                        LogicalOperator =IndicativeExchangeRates.FilterSort.Enums.LogicalOperation.Or
                    }
                };

                List<ExpressionSort> sorts = new List<ExpressionSort>
                {
                    new ExpressionSort
                    {
                        PropertyName =IndicativeExchangeRates.FilterSort.Enums.FilterColumNames.CurrencyCode,
                        SortDirection = IndicativeExchangeRates.FilterSort.Enums.SortDirection.Ascending
                    },
                    new ExpressionSort
                    {
                        PropertyName =IndicativeExchangeRates.FilterSort.Enums.FilterColumNames.ForexBuying,
                        SortDirection = IndicativeExchangeRates.FilterSort.Enums.SortDirection.Descending
                    },
                };

                era.RequestedOutput = "OutputXML";
                var result = Task.Run(() => era.GetFilteredAndSortedData(filters, sorts));
                textBox1.Text = result.Result.ToString();
            }
        }

        private async void buttonXMLAsync_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                era.RequestedOutput = "OutputXML";
                var result = await era.GetAllData();
                textBox1.Text = result.ToString();
            }
        }

        private void buttonCSV_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                era.RequestedOutput = "OutputCSV";
                var result = Task.Run(() => era.GetAllData());
                textBox1.Text = result.Result.ToString();
            }
        }

        private async void buttonCSVAsync_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                era.RequestedOutput = "OutputCSV";
                var result = await era.GetAllData();
                textBox1.Text = result.ToString();
            }
        }

        private void buttonJSON_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                era.RequestedOutput = "OutputJSON";
                var result = Task.Run(() => era.GetAllData());
                textBox1.Text = result.Result.ToString();
            }
        }

        private async void buttonJSONAsync_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;

            using (IndicativeExchangeRates.Host.ExchangeRateAPI era = new IndicativeExchangeRates.Host.ExchangeRateAPI("muratyasar", "denemetry!4"))
            {
                era.RequestedOutput = "OutputJSON";
                var result = await era.GetAllData();
                textBox1.Text = result.ToString();
            }
        }
    }
}
