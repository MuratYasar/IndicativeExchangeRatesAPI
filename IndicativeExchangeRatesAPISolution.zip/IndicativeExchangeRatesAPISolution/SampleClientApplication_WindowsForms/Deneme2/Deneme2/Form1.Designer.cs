﻿namespace Deneme2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonXML = new System.Windows.Forms.Button();
            this.buttonCSV = new System.Windows.Forms.Button();
            this.buttonJSON = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.buttonXMLAsync = new System.Windows.Forms.Button();
            this.buttonCSVAsync = new System.Windows.Forms.Button();
            this.buttonJSONAsync = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonXML
            // 
            this.buttonXML.Location = new System.Drawing.Point(27, 21);
            this.buttonXML.Name = "buttonXML";
            this.buttonXML.Size = new System.Drawing.Size(113, 23);
            this.buttonXML.TabIndex = 0;
            this.buttonXML.Text = "XML";
            this.buttonXML.UseVisualStyleBackColor = true;
            this.buttonXML.Click += new System.EventHandler(this.buttonXML_Click);
            // 
            // buttonCSV
            // 
            this.buttonCSV.Location = new System.Drawing.Point(27, 136);
            this.buttonCSV.Name = "buttonCSV";
            this.buttonCSV.Size = new System.Drawing.Size(113, 23);
            this.buttonCSV.TabIndex = 1;
            this.buttonCSV.Text = "CSV";
            this.buttonCSV.UseVisualStyleBackColor = true;
            this.buttonCSV.Click += new System.EventHandler(this.buttonCSV_Click);
            // 
            // buttonJSON
            // 
            this.buttonJSON.Location = new System.Drawing.Point(27, 246);
            this.buttonJSON.Name = "buttonJSON";
            this.buttonJSON.Size = new System.Drawing.Size(113, 23);
            this.buttonJSON.TabIndex = 2;
            this.buttonJSON.Text = "JSON";
            this.buttonJSON.UseVisualStyleBackColor = true;
            this.buttonJSON.Click += new System.EventHandler(this.buttonJSON_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(171, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(617, 426);
            this.textBox1.TabIndex = 3;
            // 
            // buttonXMLAsync
            // 
            this.buttonXMLAsync.Location = new System.Drawing.Point(27, 64);
            this.buttonXMLAsync.Name = "buttonXMLAsync";
            this.buttonXMLAsync.Size = new System.Drawing.Size(113, 23);
            this.buttonXMLAsync.TabIndex = 4;
            this.buttonXMLAsync.Text = "XML Async";
            this.buttonXMLAsync.UseVisualStyleBackColor = true;
            this.buttonXMLAsync.Click += new System.EventHandler(this.buttonXMLAsync_Click);
            // 
            // buttonCSVAsync
            // 
            this.buttonCSVAsync.Location = new System.Drawing.Point(27, 176);
            this.buttonCSVAsync.Name = "buttonCSVAsync";
            this.buttonCSVAsync.Size = new System.Drawing.Size(113, 23);
            this.buttonCSVAsync.TabIndex = 5;
            this.buttonCSVAsync.Text = "CSV Async";
            this.buttonCSVAsync.UseVisualStyleBackColor = true;
            this.buttonCSVAsync.Click += new System.EventHandler(this.buttonCSVAsync_Click);
            // 
            // buttonJSONAsync
            // 
            this.buttonJSONAsync.Location = new System.Drawing.Point(27, 286);
            this.buttonJSONAsync.Name = "buttonJSONAsync";
            this.buttonJSONAsync.Size = new System.Drawing.Size(113, 23);
            this.buttonJSONAsync.TabIndex = 6;
            this.buttonJSONAsync.Text = "JSON Async";
            this.buttonJSONAsync.UseVisualStyleBackColor = true;
            this.buttonJSONAsync.Click += new System.EventHandler(this.buttonJSONAsync_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonJSONAsync);
            this.Controls.Add(this.buttonCSVAsync);
            this.Controls.Add(this.buttonXMLAsync);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.buttonJSON);
            this.Controls.Add(this.buttonCSV);
            this.Controls.Add(this.buttonXML);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonXML;
        private System.Windows.Forms.Button buttonCSV;
        private System.Windows.Forms.Button buttonJSON;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button buttonXMLAsync;
        private System.Windows.Forms.Button buttonCSVAsync;
        private System.Windows.Forms.Button buttonJSONAsync;
    }
}

